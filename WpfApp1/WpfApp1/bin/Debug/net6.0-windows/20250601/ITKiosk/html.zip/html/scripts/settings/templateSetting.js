var kioskTemplates = [
  "component.admin", //後台管理頁面
  "component.adminVerify", // 後台頁面驗證
  "component.deviceOpen", //硬體檢查頁
  "component.register", //註冊頁第二頁
  "component.mainMenu", //主頁內頁
  "component.MuseumID", //買票第四頁
  "component.ProductChoice", //買票第四頁
  "component.ProductChoiceTicket", //選票第五頁
  "component.ProductChoiceReserTicket", //選票第五頁
  "component.ConfirmDetail", //結帳第六頁
  "component.BillSetting", //載具第六之二頁
  "component.Vehicle", //載具第七頁
  "component.Unumber", //統編第八頁
  "component.Payment", //結帳提示第十頁
  "component.common", //
  "component.PaySuccess", //
  "component.PrintFail", //
  "component.ProductDescription", //
  "component.Country", //買票第四頁
  "component.ChooseSeat", //座位選擇頁
];
